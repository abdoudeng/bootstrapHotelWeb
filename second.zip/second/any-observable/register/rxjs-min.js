'use strict';
require('../register')('rxjs/Observable', {Observable: require('rxjs/Observable').Observable});
