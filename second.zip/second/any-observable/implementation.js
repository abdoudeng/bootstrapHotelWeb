'use strict';
module.exports = require('./register')().implementation;
